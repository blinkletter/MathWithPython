# Python as a Tool
Python is not just a computer language, it is a set of useful tools. We will not be programming in this class, we will be "using". Almost all programming will be set up in advance. All students will need to do is change a few variables and point the tools to their own data files. Along the way you will learn a bit of Python, just by watching it pass you by as you use the tools.

The [Readme.ipynb](Readme.ipynb) has detailed descriptions of each notebook.
